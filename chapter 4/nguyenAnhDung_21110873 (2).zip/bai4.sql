﻿--Cho biết danh sách các người thợ hiện không tham gia vào một hợp đồng sửa chữa nào

SELECT T.TenTho
FROM Tho T INNER JOIN ChiTietHD CT ON T.MaTho = CT.MaTho
WHERE T.MaTho IS NULL

-- Cho biết danh sách những hợp đồng đã thanh lý nhưng chưa được thanh toán tiền đầy đủ.

SELECT HD.*
FROM HopDong HD JOIN PhieuThu PT ON HD.SoHD = PT.SoHD
WHERE PT.SoHD is NULL 

-- Cho biết danh sách những hợp đồng cần phải hoàn tất trước ngày 31/12/2002
SELECT HD.*
FROM HopDong HD
WHERE HD.NgayNgThu < '2002-12-31'

--  Cho biết người thợ nào thực hiện công việc nhiều nhất.

SELECT KQ2.MaTho
FROM (SELECT MAX(SL) AS SL
		FROM (SELECT HD.MaTho, COUNT(HD.MaTho) AS SL
			FROM ChiTietHD HD
			GROUP BY HD.MaTho
			) KQ 
		)  KQ INNER JOIN 
		(SELECT HD.MaTho, COUNT(HD.MaTho) AS SL
			FROM ChiTietHD HD
			GROUP BY HD.MaTho) KQ2 ON KQ.SL = KQ2.SL 

--Cho biết người thợ nào có tổng trị giá công việc được giao cao nhất.

SELECT KQ2.MaTho
FROM (SELECT MAX(Tien) AS SL
		FROM (SELECT HD.MaTho, SUM(HD.TriGiaCV) AS Tien
			FROM ChiTietHD HD
			GROUP BY HD.MaTho
			) KQ 
		)  KQ INNER JOIN 
		(SELECT HD.MaTho, Sum(HD.TriGiaCV) AS SL
			FROM ChiTietHD HD
			GROUP BY HD.MaTho) KQ2 ON KQ.SL = KQ2.SL 